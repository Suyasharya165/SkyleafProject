package com.ems.controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.beans.BillingDetails;
import com.ems.beans.Card;
import com.ems.beans.CardExpiry;
import com.ems.beans.Pay;
import com.ems.beans.ReturnLinks;
import com.ems.repositiory.BillingDetailsRepositiory;
import com.ems.repositiory.CardExpiryRepositiory;
import com.ems.repositiory.CardRepositiory;
import com.ems.repositiory.PayRepositiory;
import com.ems.repositiory.ReturnLinksRepositiory;
import com.google.gson.Gson;

@RestController
@RequestMapping("/Payment")
public class PayController 
{
	@Autowired
	private PayRepositiory repository;
	
	@Autowired
	private BillingDetailsRepositiory billingRepository;
	
	@Autowired
	private CardRepositiory cardRepository;
	
	@Autowired
	private CardExpiryRepositiory cardExpiryRepository;
	
	@Autowired
	private ReturnLinksRepositiory returnLinksRepositiory;
	
	

	@GetMapping("/readAll")
	public String readAll() {
		Iterable<Pay> all = repository.findAll();
		Gson gson = new Gson();
		String json = gson.toJson(all);

		JSONArray j1 = new JSONArray(json);
		JSONObject res = new JSONObject(j1.get(0).toString());

		Iterable<BillingDetails> billingResponse = billingRepository.findAll();

		json = gson.toJson(billingResponse);
		JSONObject billingJson = new JSONObject(new JSONArray(json).get(0).toString());
		res.put("BillingDetails", billingJson);

		// to get card

		Iterable<Card> cardResponse = cardRepository.findAll();

		json = gson.toJson(cardResponse);
		JSONObject cardJson = new JSONObject(new JSONArray(json).get(0).toString());
		// GET the card expiry
		
		Iterable<CardExpiry> cardExpiry = cardExpiryRepository.findAll();

		json = gson.toJson(cardExpiry);
		JSONObject cardExpiryJson = new JSONObject(new JSONArray(json).get(0).toString());
		cardJson.put("caredExpiry", cardExpiryJson);

		res.put("card", cardJson);
		
		// Get the returnLink
		
	    Iterable<ReturnLinks> returnLinks = returnLinksRepositiory.findAll();
		
		json = gson.toJson(returnLinks);
		//JSONObject returnLinksJson = new JSONObject(new JSONArray(json).get(0).toString());
		res.put("returnLinks", new JSONArray(json));
		
		return res.toString();
		
	}

	@PostMapping("/create")
	public Pay create(@RequestBody Pay payment) {
		return repository.save(payment);
	}

	@PutMapping("/update")
	public Pay update(@RequestBody Pay payment) {
		return repository.save(payment);
	}

	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable String id) {
		repository.deleteById(id);
	}


}
