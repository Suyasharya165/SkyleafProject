package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.beans.BillingDetails;
import com.ems.repositiory.BillingDetailsRepositiory;

@RestController
@RequestMapping("/BillingDetails")
public class BillingDetailsController 
{
	@Autowired
	private BillingDetailsRepositiory billingDetailsRepositiory; 
	
	@GetMapping("/readAll")
	public Iterable<BillingDetails> readAll()
	{
		Iterable<BillingDetails> all = billingDetailsRepositiory.findAll();
		return all;
	}
	@PostMapping("/create")
	public BillingDetails create(@RequestBody BillingDetails billingDetails)
	{
		return billingDetailsRepositiory.save(billingDetails);
	}
	
	@PutMapping("/update")
	public BillingDetails update(@RequestBody BillingDetails billingDetails)
	{
		return billingDetailsRepositiory.save(billingDetails);
	}

}
