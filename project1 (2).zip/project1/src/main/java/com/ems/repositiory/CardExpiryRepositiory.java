package com.ems.repositiory;

import org.springframework.data.repository.CrudRepository;

import com.ems.beans.CardExpiry;

public interface CardExpiryRepositiory extends CrudRepository<CardExpiry, String> {

}
