package com.ems.repositiory;

import org.springframework.data.repository.CrudRepository;

import com.ems.beans.Pay;

public interface PayRepositiory extends CrudRepository<Pay, String>
{

}
