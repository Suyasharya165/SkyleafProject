package com.ems.repositiory;

import org.springframework.data.repository.CrudRepository;

import com.ems.beans.ReturnLinks;

public interface ReturnLinksRepositiory extends CrudRepository<ReturnLinks, String>
{
	

}
