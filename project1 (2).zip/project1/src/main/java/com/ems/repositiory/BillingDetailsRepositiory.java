package com.ems.repositiory;

import org.springframework.data.repository.CrudRepository;

import com.ems.beans.BillingDetails;

public interface BillingDetailsRepositiory extends  CrudRepository<BillingDetails, String> {

}
