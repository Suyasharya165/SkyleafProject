package com.ems.repositiory;

import org.springframework.data.repository.CrudRepository;

import com.ems.beans.Card;

public interface CardRepositiory extends CrudRepository<Card, String> 
{

}
