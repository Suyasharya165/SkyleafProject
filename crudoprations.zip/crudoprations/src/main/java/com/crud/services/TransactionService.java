package com.crud.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.beans.Transaction;
import com.crud.repository.TransactionRepository;


@Service
public class TransactionService {

	@Autowired
	TransactionRepository transactionRepo;
	@Autowired
	ReturnLinksService retLinkService;
	
	public List<Transaction> findAll()
	{
		Iterable data=transactionRepo.findAll();
		Iterator dataloop=data.iterator();
		List<Transaction> newData=new ArrayList<Transaction>();
		while(dataloop.hasNext())
		{
			newData.add((Transaction)dataloop.next());
		}
		return newData;
	}
	public Transaction findById(String id)
	{
		Optional<Transaction> opt=transactionRepo.findById(id);
		Transaction tr=null;
		if(opt.isPresent())
			tr=opt.get();
		return tr;
	}
	public Transaction save(Transaction transaction)
	{
		
		
		return transactionRepo.save(transaction);
	}
}
