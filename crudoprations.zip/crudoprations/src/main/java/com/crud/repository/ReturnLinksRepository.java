package com.crud.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.crud.beans.ReturnLinks;



@Repository
public interface ReturnLinksRepository extends CrudRepository<ReturnLinks,Integer>{

}
